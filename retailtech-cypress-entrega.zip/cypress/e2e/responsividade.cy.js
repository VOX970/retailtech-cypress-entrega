describe('Módulo 05 — Responsividade e Experiência de Navegação', () => {
  beforeEach(() => {
    cy.viewport('iphone-xr')
    cy.visit('/')
  })

  it('RF-15: Validar a disponibilidade do menu principal em resolução Mobile (Responsividade)', () => {
    cy.get('.navbar-toggle, .mobile-menu-toggle, .categorymenu').should('be.visible')
  })

  it('RF-16: Validar localização de produtos e interação com o carrinho em Mobile (Responsividade)', () => {
    cy.get('#filter_keyword').type('perfume{enter}')
    cy.get('.prtitle').should('be.visible')
    cy.get('.topcart, .block_7').should('be.visible')
  })
})
