describe('Módulo 03 — Gerenciamento do Carrinho', () => {
  beforeEach(() => {
    cy.visit('/')
  })

  it('RF-09: Validar a inclusão de produto no carrinho (Positivo)', () => {
    cy.get('.prtitle').first().click()
    cy.get('.cart').click()
    cy.url().should('include', 'checkout/cart')
    cy.get('.product-list').should('be.visible')
  })

  it('RF-10 e RF-11: Validar atualização de quantidade e recálculo dos valores (Positivo)', () => {
    cy.get('.prtitle').first().click()
    cy.get('.cart').click()
    cy.get('input[id^="cart_quantity"]').clear().type('2')
    cy.get('#cart_update').click()
    cy.get('input[id^="cart_quantity"]').should('have.value', '2')
  })

  it('RF-12: Validar submissão/remoção até carrinho vazio e mensagem da interface (Comportamento)', () => {
    cy.get('.prtitle').first().click()
    cy.get('.cart').click()
    cy.get('.btn-sm.btn-default').first().click() // Botão de remoção
    cy.get('.contentpanel').should('contain.text', 'Your shopping cart is empty!')
  })

  it('RF-12: Validar tentativa de adicionar quantidade 0 ou inválida ao carrinho (Negativo)', () => {
    cy.get('.prtitle').first().click()
    cy.get('#product_quantity').clear().type('0')
    cy.get('.cart').click()
    // A interface impede ou zera/reverte para o padrão
    cy.get('body').should('be.visible')
  })
})
