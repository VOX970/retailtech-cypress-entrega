describe('Módulo 02 — Catálogo e Apresentação de Produtos', () => {
  beforeEach(() => {
    cy.visit('/')
  })

  it('RF-05: Validar apresentação de informações essenciais dos produtos na listagem (Positivo)', () => {
    cy.get('.prtitle').first().should('be.visible').and('not.be.empty')
    cy.get('.price').first().should('be.visible')
    cy.get('.thumbnail img').first().should('be.visible')
  })

  it('RF-06: Validar navegação da listagem para a página de detalhes (Positivo)', () => {
    cy.get('.prtitle').first().invoke('text').then((productName) => {
      cy.get('.prtitle').first().click()
      cy.get('.bcrumb .active').should('contain.text', productName.trim())
      cy.get('.productname').should('be.visible')
    })
  })

  it('RF-07: Validar o comportamento da busca para produtos inexistentes (Negativo)', () => {
    cy.get('#filter_keyword').type('produtoinexistente123999{enter}')
    cy.get('.contentpanel').should('contain.text', 'There is no product that matches the search criteria.')
  })

  it('RF-08: Validar consistência de preço entre a listagem e a página de detalhes (Consistência)', () => {
    cy.get('.thumbnail').first().within(() => {
      cy.get('.oneprice, .pricenew').first().invoke('text').as('listPrice')
    })
    cy.get('.prtitle').first().click()
    cy.get('@listPrice').then((listPrice) => {
      cy.get('.productfiltermember .productprice, .productprice').first().invoke('text').then((detailPrice) => {
        expect(detailPrice.trim()).to.eq(listPrice.trim())
      })
    })
  })
})
