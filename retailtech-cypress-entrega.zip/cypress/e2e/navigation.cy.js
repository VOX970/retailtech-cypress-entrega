describe('Módulo 01 — Navegação e Organização da Interface', () => {
  beforeEach(() => {
    cy.visit('/')
  })

  it('RF-01: Validar a navegação entre a página inicial e a categoria Skincare (Positivo)', () => {
    cy.get('a[href*="product/category&path=93"]').contains('Skincare').click()
    cy.get('.maintext').should('contain.text', 'Skincare')
    cy.url().should('include', 'path=93')
  })

  it('RF-02: Validar se a seleção da categoria Apparel exibe os produtos correspondentes (Positivo)', () => {
    cy.get('a[href*="product/category&path=68"]').contains('Apparel & accessories').click()
    cy.get('.maintext').should('contain.text', 'Apparel & accessories')
    cy.get('.thumbnails .col-md-3').should('have.length.greaterThan', 0)
  })

  it('RF-03: Validar retorno à página inicial via logo/link de navegação (Positivo)', () => {
    cy.get('a[href*="product/category&path=93"]').contains('Skincare').click()
    cy.get('.logo').click()
    cy.url().should('eq', `${Cypress.config().baseUrl}`)
  })

  it('RF-04: Validar os estados e comportamentos do menu de categorias (Comportamento)', () => {
    cy.get('.categorymenu > ul > li').first().trigger('mouseover')
    cy.get('.categorymenu > ul > li').first().find('a').should('be.visible')
  })
})
