describe('Módulo 04 — Formulários e Validação de Interface', () => {
  it('RF-13: Validar comportamento do formulário de contato sem campos obrigatórios (Negativo)', () => {
    cy.visit('/index.php?rt=content/contact')
    cy.get('button[title="Submit"]').click()
    cy.get('.element_error, .alert-error, .has-error').should('be.visible')
  })

  it('RF-13: Validar erro ao tentar efetuar login sem preencher credenciais (Negativo)', () => {
    cy.visit('/index.php?rt=account/login')
    cy.get('button[title="Login"]').click()
    cy.get('.alert-error, .alert-danger').should('contain.text', 'Error: No match for E-Mail Address and/or Password.')
  })

  it('RF-14: Validar apresentação de mensagem de orientação no cadastro (Comportamento)', () => {
    cy.visit('/index.php?rt=account/login')
    cy.get('button[title="Continue"]').click()
    cy.get('.maintext').should('contain.text', 'Create Account')
    cy.get('#AccountFrm').should('be.visible')
  })
})
